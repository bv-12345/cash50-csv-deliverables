import csv
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name('csv_dedupe.py')

class DedupeTests(unittest.TestCase):
    def run_case(self, content, *args):
        with tempfile.TemporaryDirectory() as d:
            src, dst = Path(d)/'in.csv', Path(d)/'out.csv'
            src.write_text(content)
            r = subprocess.run([sys.executable, str(SCRIPT), str(src), '-o', str(dst), *args], capture_output=True, text=True)
            return r, dst.read_text() if dst.exists() else None

    def test_exact_preserves_spaces(self):
        r, out = self.run_case('id,name\n1,A\n1,A\n1, A\n')
        self.assertEqual(r.returncode, 0)
        self.assertIn('duplicates_removed=1', r.stdout)
        self.assertEqual(out, 'id,name\n1,A\n1, A\n')

    def test_last_value_first_key_order(self):
        r, out = self.run_case('id,name\n1,A\n2,B\n1,C\n', '-k', 'id', '--keep', 'last')
        self.assertEqual(r.returncode, 0)
        self.assertEqual(out, 'id,name\n1,C\n2,B\n')

    def test_bad_rows_do_not_create_output(self):
        for data in ['id,name\n1\n', 'id,name\n1,A,extra\n', 'id,id\n1,2\n']:
            with self.subTest(data=data):
                r, out = self.run_case(data)
                self.assertEqual(r.returncode, 2)
                self.assertIsNone(out)

    def test_missing_key(self):
        r, out = self.run_case('id,name\n1,A\n', '-k', 'absent')
        self.assertEqual(r.returncode, 2)
        self.assertIsNone(out)

if __name__ == '__main__': unittest.main()
