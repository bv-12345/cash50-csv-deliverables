#!/usr/bin/env python3
"""CSV cleanup helper: dedupe rows, optional key columns, write cleaned CSV + summary."""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path


def row_key(row: dict[str, str], keys: list[str] | None) -> tuple[str, ...]:
    """Use exact values; tuple boundaries avoid delimiter collisions."""
    return tuple(row[k] for k in (keys if keys else sorted(row)))


def main() -> int:
    p = argparse.ArgumentParser(description="Dedupe a CSV by key columns or full-row hash")
    p.add_argument("input", type=Path)
    p.add_argument("-o", "--output", type=Path, required=True)
    p.add_argument("-k", "--keys", help="Comma-separated key columns (default: full row)")
    p.add_argument("--keep", choices=["first", "last"], default="first")
    args = p.parse_args()

    keys = [k.strip() for k in args.keys.split(",")] if args.keys else None
    with args.input.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            print("error: empty/invalid CSV", file=sys.stderr)
            return 2
        if len(set(reader.fieldnames)) != len(reader.fieldnames):
            print("error: duplicate column names", file=sys.stderr)
            return 2
        if keys:
            missing = [k for k in keys if k not in reader.fieldnames]
            if missing:
                print(f"error: missing columns: {missing}", file=sys.stderr)
                return 2
        seen: dict[tuple[str, ...], dict[str, str]] = {}
        order: list[tuple[str, ...]] = []
        total = 0
        for row in reader:
            total += 1
            if None in row or any(v is None for v in row.values()):
                print(f"error: malformed row {reader.line_num}", file=sys.stderr)
                return 2
            k = row_key(row, keys)
            if k not in seen:
                seen[k] = row
                order.append(k)
            elif args.keep == "last":
                seen[k] = row

    with args.output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(reader.fieldnames))
        writer.writeheader()
        for k in order:
            writer.writerow(seen[k])

    kept = len(order)
    print(f"rows_in={total} rows_out={kept} duplicates_removed={total-kept} keep={args.keep} keys={keys or 'FULL_ROW'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
