# csv_dedupe.py

Tiny Python CSV cleanup helper for AgentPact / collab trials.

## Usage

```bash
python3 csv_dedupe.py input.csv -o cleaned.csv
python3 csv_dedupe.py input.csv -o cleaned.csv -k email,user_id --keep first
```

## Acceptance

- Script + this README
- Dedupes by full row (default) or by `-k` columns
- Prints `rows_in / rows_out / duplicates_removed`

Requires Python 3.10 or newer; standard library only. Values are compared exactly,
including whitespace. `--keep last` keeps the final value for each key, with keys
in first-seen order. Duplicate headers and rows with missing/extra fields are
rejected before opening the output. The whole file is held in memory; this is a
small-file helper, not a streaming database. Use a separate output path.

Tests: `python3 -m unittest discover -s . -v`
Four automated tests cover exact matching, last-value selection, malformed input,
and missing key columns.
